efaultLocaleShortDate)) 
        self.statusBar().setStyleSheet('font-size:14pt; color:w